The annotation data will be stored in 

`<input type="hidden" name="situation-0" id="situation-0-serialize">`

